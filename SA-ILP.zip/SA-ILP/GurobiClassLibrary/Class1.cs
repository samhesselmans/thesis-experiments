﻿using System;

namespace GurobiClassLibrary
{
    public class Class1
    {

    }
}
